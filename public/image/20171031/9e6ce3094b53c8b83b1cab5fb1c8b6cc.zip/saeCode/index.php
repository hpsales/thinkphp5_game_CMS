<?php
	echo "测试";
?>